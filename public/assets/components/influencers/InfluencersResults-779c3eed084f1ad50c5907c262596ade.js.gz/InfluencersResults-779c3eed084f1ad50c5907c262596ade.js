(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
var classNames = require('classnames');

var Button = React.createClass({displayName: "Button",

  getInitialState: function(){
    return {active: false};
  },

  click(){
      this.setState({active: !this.state.active});
  },

  render: function(){
    var btnClass = classNames({
      'btn btn-info': true,
      'active': this.state.active
    });
    return (
      React.createElement("button", {type: "button", className: btnClass, onClick: this.click}, this.props.name)
    );
  }
});

var ButtonGroup = React.createClass({displayName: "ButtonGroup",
  render: function(){

    var createListItem = function(optionName){
      return React.createElement(Button, {key: optionName, name: optionName});
    };

    return(
      React.createElement("div", {className: "row"}, 
        React.createElement("div", {className: "col-md-2"}, 
          React.createElement("h5", null, " ", this.props.title)
        ), 
        React.createElement("div", {className: "col-md-8"}, 
          React.createElement("div", {className: "btn-group", role: "group", "aria-label": "..."}, 
            this.props.items.map(createListItem)
            )
        )
    )
    );
  }
});

module.exports = ButtonGroup;


},{"classnames":7}],2:[function(require,module,exports){
var ListItemWithLink = React.createClass({displayName: "ListItemWithLink",
  render: function(){
    return (
      React.createElement("li", null, React.createElement("a", {href: "#"}, this.props.option))
    );
  }
});


var DropDownFormGroup = React.createClass({displayName: "DropDownFormGroup",


  render: function(){

    var createListItem = function(optionName){
      return React.createElement(ListItemWithLink, {key: optionName, option: optionName});
    };

    return(
      React.createElement("div", {className: "row"}, 
        React.createElement("div", {className: "col-md-2"}, 
          React.createElement("h5", null, " ", this.props.title)
        ), 
        React.createElement("div", {className: "col-md-8"}, 
          React.createElement("div", {className: "form-group"}, 
            React.createElement("div", {className: "input-group-btn"}, 
              React.createElement("button", {type: "button", className: "btn btn-info dropdown-toggle", "data-toggle": "dropdown", "aria-haspopup": "true", "aria-expanded": "false"}, this.props.title, React.createElement("span", {className: "caret"})), 
              React.createElement("ul", {className: "dropdown-menu"}, 
                this.props.items.map(createListItem)
              )
            )
          )
        )
      )
    );
  }
});

module.exports = DropDownFormGroup;


},{}],3:[function(require,module,exports){
var DropDownFormGroup = require('../common/DropDownFormGroup.js.jsx');
var ButtonGroup = require('../common/ButtonGroup.js.jsx');

var InfluencersFilters = React.createClass({displayName: "InfluencersFilters",
  render: function(){
    return (

        React.createElement("div", {className: "row"}, 
            React.createElement(ButtonGroup, {title: "Type of Promotion ", items: ["Review", "Photo & Comment", "Sale for Fans"]}), 
            React.createElement("hr", null), 
            React.createElement(ButtonGroup, {title: "Frequency ", items: ["One-Time Shoutout", "On-going relationship"]}), 
            React.createElement("hr", null), 
            React.createElement(ButtonGroup, {title: "Personality ", items: ["Quirky", "Witty", "Bubbly", "Sassy", "Conservative"]}), 
            React.createElement("hr", null), 
            React.createElement(DropDownFormGroup, {title: "Budget", items: ["$0-$10", "$10-$30", "$30-$50", "$50-$75", "$75-$100", "$100+"]})
        )
    );
  }
});


module.exports = InfluencersFilters;


},{"../common/ButtonGroup.js.jsx":1,"../common/DropDownFormGroup.js.jsx":2}],4:[function(require,module,exports){
var InfluencersResultsRow = require('./InfluencersResultsProfile.js.jsx');

var InfluencersResultsContent = React.createClass({displayName: "InfluencersResultsContent",
  //var array = new Array();
  render: function(){
   //var someTestInfluencers = array(this.props.Influencers);

    return(
      React.createElement("div", {className: "container"}, 
        React.createElement(InfluencersResultsRow, {influencers: this.props.Influencers})
      )
    );
  }
});

module.exports = InfluencersResultsContent;


},{"./InfluencersResultsProfile.js.jsx":5}],5:[function(require,module,exports){
var BadgeList = React.createClass({displayName: "BadgeList",
  render: function(){

    var createBadge = function(tagName, index){
      return React.createElement("span", {className: "badge", key: index}, tagName) ;
    };

    return(
      React.createElement("div", null, " ", this.props.tags.map(createBadge), " ")
    );
  }

});

var ListOfLinks = React.createClass({displayName: "ListOfLinks",
  render: function(){
    var createListItem = function(linkSet, index){
      return React.createElement("li", {key: index}, React.createElement("a", {href: linkSet.link}, " ", linkSet.name, " "))
    };

    return (
      React.createElement("ul", null
      )
    );
  }

});

var InfluencersResultsProfile = React.createClass({displayName: "InfluencersResultsProfile",
  render: function(){
    var panelStyle = {
      padding: 0,
    }

    var nameStyle = {
      textDecoration: "none",
      textAlign: "center"
    };
   var smi=this.props.imageLink;
   var photoToView=smi.scheme+'://'+smi.host+smi.path
	 var influencer_page = '/influencers/' + this.props.influencer_id
    return(
      React.createElement("div", {className: "col-md-3"}, 
        React.createElement("div", {className: "panel panel-default"}, 
          React.createElement("div", {className: "panel-body", style: panelStyle}, 
            React.createElement("a", {href: influencer_page}, React.createElement("img", {src: photoToView, className: "img-responsive"}))
          ), 
          React.createElement("div", {className: "panel-footer"}, 

            React.createElement("a", {href: influencer_page, style: nameStyle}, React.createElement("h3", null, this.props.first_name)), 
            React.createElement("h5", {style: nameStyle}, this.props.industry), 
            React.createElement(ListOfLinks, {links: this.props.socialLinks}), 
            React.createElement(BadgeList, {tags: this.props.badges})

          )
        )
      )
    );
  }
});

var InfluencersResultsRow = React.createClass({displayName: "InfluencersResultsRow",
  render: function(){

   var InfluencerInfo = this.props.influencers;
    var createInfluencerProfile = function(inf, index){
      return React.createElement(InfluencersResultsProfile, {
				key: index, 
				influencer_id: inf.user.id, 
        first_name: inf.user.first_name, 
				imageLink: inf.social_media_info.profile_pic, 
        badges: ["Grumpy", "Sneezy"], 
        socialLinks: inf.socialLinks, 
        industry: inf.industries[0].name}

      );
    };

    return (
      React.createElement("div", {className: "row"}, 
        InfluencerInfo.map(createInfluencerProfile)
      )
    );
  }

});

module.exports = InfluencersResultsRow;


},{}],6:[function(require,module,exports){
var InfluencersResultsContent = require('./InfluencersResultsContent.js.jsx');
var InfluencersFilters = require('./InfluencersFilters.js.jsx');

var InfluencersResults = React.createClass({
  displayName: 'InfluencersResults',

  render: function () {
    if (this.props.errorMessage) {
      return React.createElement(
        'div',
        null,
        ' this.state.errorMessage '
      );
    }
    mainContainerStyle = {
      marginTop: 70
    };

    return React.createElement(
      'div',
      { id: 'mainContainer', className: 'container', style: mainContainerStyle },
      React.createElement(InfluencersFilters, null),
      React.createElement('hr', null),
      React.createElement(InfluencersResultsContent, { Influencers: this.props.influencers })
    );
  }
});

module.exports = InfluencersResults;

},{"./InfluencersFilters.js.jsx":3,"./InfluencersResultsContent.js.jsx":4}],7:[function(require,module,exports){
/*!
  Copyright (c) 2016 Jed Watson.
  Licensed under the MIT License (MIT), see
  http://jedwatson.github.io/classnames
*/
/* global define */

(function () {
	'use strict';

	var hasOwn = {}.hasOwnProperty;

	function classNames () {
		var classes = [];

		for (var i = 0; i < arguments.length; i++) {
			var arg = arguments[i];
			if (!arg) continue;

			var argType = typeof arg;

			if (argType === 'string' || argType === 'number') {
				classes.push(arg);
			} else if (Array.isArray(arg)) {
				classes.push(classNames.apply(null, arg));
			} else if (argType === 'object') {
				for (var key in arg) {
					if (hasOwn.call(arg, key) && arg[key]) {
						classes.push(key);
					}
				}
			}
		}

		return classes.join(' ');
	}

	if (typeof module !== 'undefined' && module.exports) {
		module.exports = classNames;
	} else if (typeof define === 'function' && typeof define.amd === 'object' && define.amd) {
		// register as 'classnames', consistent with npm package name
		define('classnames', [], function () {
			return classNames;
		});
	} else {
		window.classNames = classNames;
	}
}());

},{}]},{},[6]);
